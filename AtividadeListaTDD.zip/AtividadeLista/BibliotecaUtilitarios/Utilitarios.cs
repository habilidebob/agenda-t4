﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaUtilitarios
{
    public class Utilitarios
    {
        public int SomarStringInteiros(string valor)
        {
            // Pendente de implementação
            return 0;
        }
        public int ValidarSenha(string senha)
        {
            // Pendente de implementação
            return 0;
        }
    }
}
