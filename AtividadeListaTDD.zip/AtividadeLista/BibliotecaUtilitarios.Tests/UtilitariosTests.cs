﻿using NUnit.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace BibliotecaUtilitarios.Tests
{
    [TestFixture]
    public class UtilitariosTests
    {
        [Test]
        public void SomarDoisNumeros()
        {
            var sut = new Utilitarios();
            var resultado = sut.SomarStringInteiros("1,2");
            Assert.That(resultado, Is.EqualTo(3));
        }
        // Continue abaixo, jovem...
    }
}
